# Changelog

## 0.1.0 - prototype
* Phase 0: four spike scripts + checklist (`spikes/`).
* Phase 1: attach / detach / make-project, working copy in `PROJECTS/<name>/`, base snapshot, offset + project start offset,
  timebase, media paths, MIDI tempo bake, master -> PROJECT track, markers and regions.
* Phase 2: three-way merge with per-conflict choice, dry-run (nothing written until Apply), shadow detach.
* Phase 3: launch second REAPER (own config), file mailbox (play / stop / locate / save / quit), heartbeat health.
* Phase 4 (partly): interrupted-operation journal, recovery planner (relaunch / reattach / pull / locate file), orphan detection in the child.
* Not started: Phase 5 show-control layer.
