-- The shipped single files must work without src/ on the path.
package.path = "./tools/?.lua;" .. package.path
local T = require("t")
local Mock = require("mock_reaper")
local Stub = require("imgui_stub")

local function run_script(path, setup)
  package.loaded["NPRpp"] = nil
  local S = Mock.install()
  package.path = "./tools/?.lua;" .. (package.path:gsub("%./src/%?%.lua;", ""))
  for k in pairs(package.loaded) do if k:match("^NP") then package.loaded[k] = nil end end
  for k in pairs(package.preload) do package.preload[k] = nil end
  local st = Stub.install(reaper)
  reaper.ImGui_CreateContext = function() return "ctx" end
  reaper.get_action_context = function() return true, "x", 0, 0 end
  reaper.atexit = function() end
  reaper.defer = function(f) S.deferred = f end
  reaper.MB = function() end
  reaper.SetToggleCommandState = function() end
  reaper.RefreshToolbar2 = function() end
  reaper.OnPlayButton, reaper.OnStopButton, reaper.SetEditCurPos = function() end, function() end, function() end
  reaper.Main_SaveProject, reaper.IsProjectDirty, reaper.Main_OnCommand = function() end, function() return 0 end, function() end
  reaper.GetPlayState, reaper.GetPlayPosition, reaper.GetCursorPosition = function() return 0 end, function() return 0 end, function() return 0 end
  reaper.GetAudioDeviceInfo = function() return true, "Test device" end
  if setup then setup(S) end
  local f = assert(loadfile(path))
  return S, st, f
end

-- main window
do
  local S, st, f = run_script("dist/NestedProjects.lua")
  local ok, err = pcall(f)
  T.ok(ok, "main bundle runs: " .. tostring(err))
  T.ok(S.deferred, "main loop scheduled")
  local ok2, err2 = pcall(S.deferred)
  T.ok(ok2, "one frame draws: " .. tostring(err2))
end

-- child helper: refuses to run outside a child, runs with the environment set
do
  local warned
  local S, st, f = run_script("dist/NestedProjectsChild.lua", function() end)
  reaper.MB = function(m) warned = m end
  local ok, err = pcall(f)
  T.ok(ok, "child bundle loads: " .. tostring(err))
  T.ok(warned and warned:find("not a NestedProjects child"), "and says so when it has no link folder")
end
T.done("test_bundle")
