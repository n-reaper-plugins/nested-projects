-- @description NestedProjects child helper: runs inside a detached child REAPER instance (started by NestedProjects)
-- @version @@VERSION@@
-- @about
--   You normally never start this yourself: NestedProjects launches the child REAPER with this script.
--   It listens to the parent (play / stop / locate / save / quit) and reports its health through small files in
--   <parent project folder>/PROJECTS/<name>/.link/. Running it again asks the running helper to close.

local r = reaper
local dir = debug.getinfo(1, "S").source:match("^@(.*[/\\])") or ""
package.path = dir .. "?.lua;" .. package.path
local Child = require("NPChild")

local EXT = "NestedProjectsChild"
if r.GetExtState(EXT, "running") == "1" and (os.time() - (tonumber(r.GetExtState(EXT, "hb")) or 0)) < 3 then
  r.SetExtState(EXT, "stop", "1", false)
  return
end

-- where is the mailbox? environment first (set by the parent), else a marker next to the project file
local link, id = os.getenv("NP_LINK_DIR"), os.getenv("NP_ID")
local function read(p) local f = io.open(p, "rb"); if not f then return nil end local s = f:read("*a"); f:close(); return s end
if not link or link == "" then
  local _, fn = r.EnumProjects(-1)
  if fn and fn ~= "" then
    local cand = fn:match("^(.*)[/\\][^/\\]*$") .. "/.link"
    local marker = read(cand .. "/child.json")
    if marker then link = cand; id = marker:match('"id"%s*:%s*"([^"]*)"') end
  end
end
if not link or link == "" then
  r.MB("This project is not a NestedProjects child (no .link folder found).", "NestedProjects child helper", 0)
  return
end

local fs = {
  read = read,
  write_atomic = function(p, s)
    local tmp = p .. ".tmp"
    local f = io.open(tmp, "wb"); if not f then return false end
    f:write(s); f:close(); os.remove(p)
    return os.rename(tmp, p) and true or false
  end,
}

local api = {
  play = function() r.OnPlayButton() end,
  stop = function() r.OnStopButton() end,
  locate = function(pos) r.SetEditCurPos(pos, true, true) end,
  save = function() r.Main_SaveProject(0, false); return r.IsProjectDirty(0) == 0 end,
  quit = function() r.Main_OnCommand(40004, 0) end,      -- File: Quit REAPER
  state = function()
    local ps = r.GetPlayState()
    local playing = (ps & 1) == 1
    local _, fn = r.EnumProjects(-1)
    local ok, dev = r.GetAudioDeviceInfo("IDENT_OUT", "")
    return { play = ps & 7, pos = playing and r.GetPlayPosition() or r.GetCursorPosition(), dirty = r.IsProjectDirty(0) == 1,
             project = fn, device = ok and dev or nil }
  end,
}

local helper = Child.new(link, id or "", api, fs, r.time_precise and function() return os.time() + (r.time_precise() % 1) end or os.time)
r.SetExtState(EXT, "running", "1", false)
r.SetExtState(EXT, "stop", "0", false)

local function shutdown()
  helper.closing = true
  pcall(helper.write_status, helper)
  r.SetExtState(EXT, "running", "0", false)
  r.SetExtState(EXT, "stop", "0", false)
end
r.atexit(shutdown)

local last_hb = 0
local function loop()
  if r.GetExtState(EXT, "stop") == "1" then shutdown(); return end
  local now = r.time_precise()
  if now - last_hb > 1 then r.SetExtState(EXT, "hb", tostring(os.time()), false); last_hb = now end
  pcall(helper.tick, helper)
  r.defer(loop)
end
loop()
