-- NPChild.lua
-- Logic of the helper that runs INSIDE a detached child REAPER instance. It answers the parent through the file mailbox:
--   * executes play / stop / locate / save / quit / ping from cmd.json and acknowledges each one
--   * writes status.json (heartbeat, play state, position, dirty flag, audio device) a couple of times a second
--   * notices when the parent stopped writing its heartbeat (orphaned child) - it keeps running, isolation is the point
-- All REAPER calls go through `api`, so this is testable offline.
--
--   api = { play(), stop(), locate(pos), save()->bool, quit(), state()->{play,pos,dirty,project,device,device_err} }

local Mail = require("NPMail")

local Child = {}
Child.__index = Child

Child.POLL = 0.1        -- seconds between mailbox checks
Child.STATUS = 0.5      -- seconds between status writes

function Child.new(link_dir, id, api, fs, clock)
  local self = setmetatable({}, Child)
  self.id, self.api, self.clock = id, api, clock
  self.mail = Mail.child(fs, link_dir, clock)
  self.last_poll, self.last_status = -1e9, -1e9
  self.closing = false
  self.orphaned = false
  return self
end

local function run(self, c)
  local a = self.api
  if c.cmd == "play" then
    local st = a.state()
    if not st.play or st.play == 0 then a.play() end
  elseif c.cmd == "stop" then a.stop()
  elseif c.cmd == "locate" then a.locate(c.pos)
  elseif c.cmd == "save" then
    if not a.save() then return false, "save failed" end
  elseif c.cmd == "quit" then
    if not a.save() then return false, "save failed: not quitting" end
    self.closing = true
    self:write_status(true)
    a.quit()
  elseif c.cmd == "ping" then
  else return false, "unknown command" end
  return true
end

function Child:write_status(force)
  local s = self.api.state()
  local parent = self.mail.parent_info()
  self.orphaned = parent ~= nil and not Mail.health.parent_alive(parent, self.clock())
  self.mail.write_status({
    id = self.id, state = self.closing and "closing" or "running", play = s.play, pos = s.pos, dirty = s.dirty,
    project = s.project, device = s.device, device_err = s.device_err, orphaned = self.orphaned or nil,
  })
end

function Child:tick()
  local now = self.clock()
  local ran = false
  if now - self.last_poll >= Child.POLL then
    self.last_poll = now
    local c = self.mail.poll()
    if c then
      local ok, err = run(self, c)
      if type(ok) ~= "boolean" then ok, err = false, tostring(err) end
      self.mail.ack(c.seq, ok, err)
      ran = true
    end
  end
  if ran or now - self.last_status >= Child.STATUS then
    self.last_status = now
    self:write_status()
  end
end

return Child
